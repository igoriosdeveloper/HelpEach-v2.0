//
//  ViewController.swift
//  helpeach
//
//  Created by Igor Astsatryan on 28.02.23.
//

import UIKit

class BrowseViewController: UIViewController {
    
    
    @IBOutlet weak var table: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configureTable()
    }


    func configureTable() {
        table.delegate = self
        table.dataSource = self
    }
    
    
}

extension BrowseViewController: UITableViewDelegate, UITableViewDataSource {
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! infoTableCell
        cell.imageView!.image = UIImage(named: "logoNum1")
        
        return cell
    }
    
    
}
